const geoip = require('geoip-lite');
const blocked = new Set((process.env.BLOCKED_COUNTRIES || '').split(',').map(s => s.trim().toUpperCase()).filter(Boolean));

const banner = `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Access Denied</title><body style="margin:0;background:#0a0e17;color:#ff4d4d;font:16px ui-monospace,Menlo,monospace;display:grid;place-items:center;min-height:100vh">
<pre style="border:1px solid #ff4d4d;padding:2rem;max-width:90vw">[ ACCESS DENIED ]\nInfrastructure Restricted\n\nIHRTECH SECURITY :: IHM</pre></body>`;

exports.geoBlock = (req, res, next) => {
  if (!blocked.size) return next();
  const hit = geoip.lookup(req.ip);
  if (hit && blocked.has(hit.country)) {
    res.status(403).set('Cache-Control', 'no-store');
    return req.accepts(['html', 'json']) === 'json' ? res.json({ error: 'access_denied' }) : res.type('html').send(banner);
  }
  next();
};

const jwt = require('jsonwebtoken');
const { User } = require('../models');

exports.cookieOpts = { httpOnly: true, sameSite: 'strict', secure: process.env.NODE_ENV === 'production', maxAge: 7 * 864e5, path: '/' };

exports.requireUser = async (req, res, next) => {
  try {
    const t = req.cookies && req.cookies.ihm_s;
    if (typeof t !== 'string') return res.status(401).json({ error: 'auth' });
    const { sub } = jwt.verify(t, process.env.JWT_SECRET);
    const u = await User.findById(String(sub));
    if (!u) return res.status(401).json({ error: 'auth' });
    req.user = u; next();
  } catch { res.status(401).json({ error: 'auth' }); }
};

// Hidden routes answer 404 to anyone without the role, so they do not reveal themselves.
exports.requireOps = (req, res, next) =>
  req.user && req.user.role === 'ops' ? next() : res.status(404).json({ error: 'not_found' });

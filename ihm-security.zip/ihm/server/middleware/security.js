const helmet = require('helmet');
const cors = require('cors');
const hpp = require('hpp');
const mongoSanitize = require('express-mongo-sanitize');
const rateLimit = require('express-rate-limit');

exports.armor = app => {
  app.disable('x-powered-by');
  app.use(helmet({
    contentSecurityPolicy: { directives: {
      defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:'], connectSrc: ["'self'"], objectSrc: ["'none'"], frameAncestors: ["'none'"], baseUri: ["'self'"]
    } },
    hsts: { maxAge: 31536000, includeSubDomains: true, preload: true },
    referrerPolicy: { policy: 'no-referrer' }
  }));
  app.use(cors({ origin: process.env.CLIENT_ORIGIN, credentials: true }));
  app.use(hpp());
  app.use((req, res, next) => { mongoSanitize.sanitize(req.body); mongoSanitize.sanitize(req.params); mongoSanitize.sanitize(req.query); next(); });
  // hard global ceiling: 100,000 requests/hour across all clients
  app.use(rateLimit({ windowMs: 3600e3, limit: 100000, keyGenerator: () => 'global', standardHeaders: true, legacyHeaders: false, message: { error: 'capacity' } }));
  // per-IP ceiling so one client cannot burn the shared budget
  app.use(rateLimit({ windowMs: 3600e3, limit: 3000, standardHeaders: true, legacyHeaders: false, message: { error: 'slow_down' } }));
};

exports.authLimiter = rateLimit({ windowMs: 15 * 60e3, limit: 20, message: { error: 'too_many_attempts' } });
exports.verifyLimiter = rateLimit({ windowMs: 60e3, limit: 15, message: { error: 'too_many_attempts' } });

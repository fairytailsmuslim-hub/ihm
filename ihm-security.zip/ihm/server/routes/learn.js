const router = require('express').Router();
const path = require('path');
const { Module, User, Leaderboard, AuditLog } = require('../models');
const { requireUser } = require('../middleware/auth');
const { verifyLimiter } = require('../middleware/security');
const lab = require('../services/labEngine');

// Public, crawlable teaser: title + summary only (module bodies stay behind the gate).
router.get('/public/:slug', async (req, res) => {
  const m = await Module.findOne({ slug: String(req.params.slug) }).select('order slug title summary');
  m ? res.json(m) : res.status(404).json({ error: 'not_found' });
});

router.use(requireUser);

const done = (user, m) => m.labs.length > 0 && m.labs.every(l => user.solved.includes(l.id));
async function gate(user, order) {
  if (order === 1) return true;
  const prev = await Module.findOne({ order: order - 1 }).select('labs');
  return !!prev && done(user, prev);
}

router.get('/modules', async (req, res) => {
  const all = await Module.find().sort('order').select('order slug title labs.id');
  let open = true;
  res.json(all.map(m => { const o = { order: m.order, slug: m.slug, title: m.title, locked: !open }; open = open && done(req.user, m); return o; }));
});

router.get('/modules/:order', async (req, res) => {
  const order = parseInt(req.params.order, 10);
  if (!Number.isInteger(order) || order < 1) return res.status(400).json({ error: 'invalid' });
  if (!(await gate(req.user, order))) return res.status(403).json({ error: 'locked' });
  const m = await Module.findOne({ order });
  if (!m) return res.status(404).json({ error: 'not_found' });
  res.json({ order, slug: m.slug, title: m.title, body: m.body, summary: m.summary,
    labs: m.labs.map(l => ({ id: l.id, title: l.title, kind: l.kind, prompt: lab.render(req.user.id, l), solved: req.user.solved.includes(l.id) })) });
});

router.get('/modules/:order/pdf', async (req, res) => {
  const order = parseInt(req.params.order, 10);
  if (!(await gate(req.user, order))) return res.status(403).json({ error: 'locked' });
  const m = await Module.findOne({ order });
  if (!m || !/^[a-z0-9-]+\.pdf$/.test(m.pdf)) return res.status(404).json({ error: 'not_found' });
  res.download(path.join(__dirname, '..', 'storage', 'pdf', m.pdf));
});

async function findLab(user, labId) {
  if (!/^m\d+-l\d+$/.test(labId)) return null;
  const m = await Module.findOne({ 'labs.id': labId });
  if (!m || !(await gate(user, m.order))) return null;
  return { m, l: m.labs.find(x => x.id === labId) };
}

router.get('/labs/:id/evidence', async (req, res) => {
  const f = await findLab(req.user, String(req.params.id));
  f ? res.json({ lines: lab.evidence(req.user.id, f.l) }) : res.status(404).json({ error: 'not_found' });
});

router.post('/labs/:id/verify', verifyLimiter, async (req, res) => {
  const f = await findLab(req.user, String(req.params.id));
  if (!f || typeof req.body.answer !== 'string' || req.body.answer.length > 200) return res.status(404).json({ error: 'not_found' });
  const ok = lab.check(req.user.id, f.l, req.body.answer);
  await AuditLog.create({ actor: req.user.handle, action: ok ? 'lab_ok' : 'lab_fail', ip: req.ip, meta: { lab: f.l.id } });
  if (!ok) return res.json({ correct: false });
  if (!req.user.solved.includes(f.l.id)) {
    const u = await User.findOneAndUpdate({ _id: req.user._id, solved: { $ne: f.l.id } }, { $push: { solved: f.l.id }, $inc: { score: 10 } }, { new: true });
    if (u) await Leaderboard.findOneAndUpdate({ user: u._id }, { handle: u.handle, score: u.score, solved: u.solved.length }, { upsert: true });
  }
  res.json({ correct: true });
});

router.get('/leaderboard', async (req, res) => res.json(await Leaderboard.find().sort('-score').limit(50).select('handle score solved -_id')));
module.exports = router;

const router = require('express').Router();
const multer = require('multer');
const crypto = require('crypto');
const mongoose = require('mongoose');
const { requireUser, requireOps } = require('../middleware/auth');
const { Module, User, AuditLog } = require('../models');
const seed = require('../services/seedParser');
const intel = require('../services/proxyIntel');

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 2 * 1024 * 1024, files: 1 },
  fileFilter: (req, f, cb) => cb(null, /^(text\/(plain|markdown|csv)|application\/json)$/.test(f.mimetype)) });

router.use(requireUser, requireOps);

router.post('/ingest', upload.single('seed'), async (req, res) => {
  const text = req.file ? req.file.buffer.toString('utf8') : (typeof req.body.text === 'string' ? req.body.text : '');
  const count = Math.min(Math.max(parseInt(req.body.count, 10) || 100, 1), 150);
  if (text.length < 200) return res.status(400).json({ error: 'seed_too_small' });
  if (!process.env.ANTHROPIC_API_KEY) return res.status(503).json({ error: 'llm_not_configured' });
  const id = crypto.randomBytes(6).toString('hex');
  await AuditLog.create({ actor: req.user.handle, action: 'ingest', ip: req.ip, meta: { id, count, bytes: text.length } });
  seed.ingest(id, text, count);                       // runs in background
  res.status(202).json({ job: id });
});

router.get('/jobs/:id', (req, res) => { const j = seed.jobs.get(String(req.params.id)); j ? res.json(j) : res.status(404).json({ error: 'not_found' }); });

router.get('/metrics', async (req, res) => {
  const m = process.memoryUsage();
  res.json({ uptime: Math.round(process.uptime()), rssMB: Math.round(m.rss / 1048576), heapMB: Math.round(m.heapUsed / 1048576),
    db: ['down', 'up', 'connecting', 'closing'][mongoose.connection.readyState], modules: await Module.countDocuments(), users: await User.countDocuments(),
    recent: await AuditLog.find().sort('-createdAt').limit(15).select('actor action ip createdAt -_id') });
});

router.post('/intel', async (req, res, next) => {
  try { res.json(await intel.lookup(String(req.body.source), req.body.target)); } catch (e) { next(e); }
});
module.exports = router;

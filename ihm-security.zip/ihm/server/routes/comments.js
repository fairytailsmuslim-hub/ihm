const router = require('express').Router();
const mongoose = require('mongoose');
const DOMPurify = require('isomorphic-dompurify');
const { Comment } = require('../models');
const { requireUser } = require('../middleware/auth');

const TARGET = /^(module|lab):[a-z0-9-]{3,80}$/;
const clean = t => DOMPurify.sanitize(String(t), { ALLOWED_TAGS: [], ALLOWED_ATTR: [] }).trim().slice(0, 1000);

router.get('/:target', async (req, res) => {
  if (!TARGET.test(req.params.target)) return res.status(400).json({ error: 'invalid' });
  res.json(await Comment.find({ target: req.params.target }).sort('createdAt').limit(500).select('parent handle text createdAt'));
});

router.post('/:target', requireUser, async (req, res) => {
  const { text, parent } = req.body;
  if (!TARGET.test(req.params.target) || typeof text !== 'string') return res.status(400).json({ error: 'invalid' });
  const body = clean(text);
  if (!body) return res.status(400).json({ error: 'empty' });
  let p = null;
  if (typeof parent === 'string' && mongoose.isValidObjectId(parent)) p = parent;
  const c = await Comment.create({ target: req.params.target, parent: p, handle: req.user.handle, text: body });
  res.status(201).json(c);
});
module.exports = router;

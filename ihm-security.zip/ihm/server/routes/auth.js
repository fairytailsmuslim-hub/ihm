const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { User, AuditLog } = require('../models');
const { authLimiter } = require('../middleware/security');
const { cookieOpts, requireUser } = require('../middleware/auth');

const s = v => typeof v === 'string' ? v : '';
const issue = (res, u) => res.cookie('ihm_s', jwt.sign({ sub: u.id }, process.env.JWT_SECRET, { expiresIn: '7d' }), cookieOpts);

router.post('/register', authLimiter, async (req, res) => {
  const { handle, email, password } = Object.fromEntries(['handle', 'email', 'password'].map(k => [k, s(req.body[k])]));
  if (password.length < 10 || password.length > 128) return res.status(400).json({ error: 'weak_password' });
  try {
    const u = await User.create({ handle, email, passHash: await bcrypt.hash(password, 12) });
    issue(res, u); res.status(201).json({ handle: u.handle });
  } catch (e) { res.status(e.code === 11000 ? 409 : 400).json({ error: e.code === 11000 ? 'exists' : 'invalid' }); }
});

router.post('/login', authLimiter, async (req, res) => {
  const u = await User.findOne({ email: s(req.body.email).toLowerCase() });
  const ok = u && await bcrypt.compare(s(req.body.password), u.passHash);
  await AuditLog.create({ actor: u ? u.handle : 'unknown', action: ok ? 'login' : 'login_fail', ip: req.ip });
  if (!ok) return res.status(401).json({ error: 'bad_credentials' });
  issue(res, u); res.json({ handle: u.handle });
});

router.post('/logout', (req, res) => res.clearCookie('ihm_s', cookieOpts).json({ ok: true }));
router.get('/me', requireUser, (req, res) => res.json({ handle: req.user.handle, role: req.user.role, score: req.user.score }));
module.exports = router;

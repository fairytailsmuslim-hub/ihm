const router = require('express').Router();
const { Module } = require('../models');
const esc = s => String(s).replace(/[<>&'"]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;' }[c]));

router.get('/robots.txt', (req, res) => res.type('text').send(`User-agent: *\nAllow: /\nSitemap: ${process.env.SITE_URL}/sitemap.xml\n`));
router.get('/sitemap.xml', async (req, res) => {
  const mods = await Module.find().sort('order').select('slug updatedAt');
  const urls = [`<url><loc>${esc(process.env.SITE_URL)}/</loc></url>`,
    ...mods.map(m => `<url><loc>${esc(process.env.SITE_URL)}/learn/${esc(m.slug)}</loc><lastmod>${m.updatedAt.toISOString()}</lastmod></url>`)];
  res.type('application/xml').set('Cache-Control', 'public, max-age=3600').send(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls.join('')}</urlset>`);
});
module.exports = router;

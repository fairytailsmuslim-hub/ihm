require('dotenv').config();
const mongoose = require('mongoose');
const { User } = require('../models');
const email = (process.argv[2] || '').toLowerCase();
mongoose.connect(process.env.MONGO_URI).then(async () => {
  const r = await User.updateOne({ email }, { role: 'ops' });
  console.log(r.matchedCount ? `${email} -> ops` : 'user not found (register first)');
  process.exit(0);
});

require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cookieParser = require('cookie-parser');
const { geoBlock } = require('./middleware/geoBlock');
const { armor } = require('./middleware/security');

const app = express();
app.set('trust proxy', 1);
app.use(geoBlock);               // first: refuse before any work is done
armor(app);                      // helmet, cors, rate limits, sanitizers
app.use(express.json({ limit: '200kb' }));
app.use(cookieParser());

app.use('/api/auth', require('./routes/auth'));
app.use('/api/learn', require('./routes/learn'));
app.use('/api/comments', require('./routes/comments'));
app.use(`/api/${process.env.OPS_PREFIX}`, require('./routes/ops'));
app.use(require('./routes/seo'));

app.use((req, res) => res.status(404).json({ error: 'not_found' }));
app.use((err, req, res, next) => {
  console.error(err.message);
  res.status(err.status || 500).json({ error: err.expose ? err.message : 'server_error' });
});

mongoose.set('sanitizeFilter', true);
mongoose.connect(process.env.MONGO_URI).then(() => {
  app.listen(process.env.PORT || 8080, () => console.log('IHM online'));
}).catch(e => { console.error('db', e.message); process.exit(1); });

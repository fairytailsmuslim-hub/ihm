const { Schema, model } = require('mongoose');

const User = model('User', new Schema({
  handle: { type: String, required: true, unique: true, match: /^[a-zA-Z0-9_]{3,24}$/ },
  email: { type: String, required: true, unique: true, lowercase: true, match: /^[^\s@]+@[^\s@]+\.[^\s@]+$/ },
  passHash: { type: String, required: true },
  role: { type: String, enum: ['learner', 'ops'], default: 'learner' },
  solved: { type: [String], default: [] },
  score: { type: Number, default: 0 }
}, { timestamps: true }));

const Module = model('Module', new Schema({
  order: { type: Number, required: true, unique: true, index: true },
  slug: { type: String, required: true, unique: true, match: /^[a-z0-9-]{3,80}$/ },
  title: { en: String, ur: String },
  body: { en: String, ur: String },
  summary: String,
  labs: [{ id: String, title: String, kind: { type: String, enum: ['whois', 'domain', 'token', 'ipoffset'] }, prompt: String }],
  pdf: String
}, { timestamps: true }));

const Leaderboard = model('Leaderboard', new Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User', unique: true },
  handle: String, score: { type: Number, index: true }, solved: Number
}, { timestamps: true }));

const AuditLog = model('AuditLog', new Schema({
  actor: String, action: { type: String, index: true }, ip: String, meta: Schema.Types.Mixed
}, { timestamps: true }));

const Comment = model('Comment', new Schema({
  target: { type: String, index: true },
  parent: { type: Schema.Types.ObjectId, default: null, index: true },
  handle: String, text: { type: String, maxlength: 1000 }
}, { timestamps: true }));

module.exports = { User, Module, Leaderboard, AuditLog, Comment };

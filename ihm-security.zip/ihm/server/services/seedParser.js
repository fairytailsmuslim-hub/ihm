// Seed parser: uploaded text -> IOC summary -> N bilingual modules (EN + Roman Urdu), 5 labs each, one PDF per module.
const fs = require('fs');
const path = require('path');
const PDFDocument = require('pdfkit');
const { Module } = require('../models');

const PDF_DIR = path.join(__dirname, '..', 'storage', 'pdf');
const jobs = new Map();
exports.jobs = jobs;

const IOC = {
  ipv4: /\b(?:\d{1,3}\.){3}\d{1,3}\b/g, domain: /\b[a-z0-9-]+(?:\.[a-z0-9-]+)*\.(?:com|net|org|io|ru|cn|xyz|info|onion)\b/gi,
  sha256: /\b[a-f0-9]{64}\b/gi, email: /\b[\w.+-]+@[\w-]+\.[\w.]+\b/g
};
const extract = t => Object.fromEntries(Object.entries(IOC).map(([k, re]) => [k, (t.match(re) || []).length]));

const SYS = `You write OSINT training modules. Reply with ONE JSON object and nothing else.
Rules: teach techniques and methodology only. Never include real people's names, personal data, or live credentials from the source; abstract them into generic, fictional examples. Labs must be solvable only against synthetic data supplied by the platform.
Schema: {"title":{"en":str,"ur":str},"summary":str,"body":{"en":str,"ur":str},"labs":[{"title":str,"kind":"whois|domain|token|ipoffset","prompt":str}]}
body.en and body.ur are each ~450 words (ur = Roman Urdu in Latin script). Exactly 5 labs. Prompts may use placeholders {domain} {base} {offset} {token} {ip}.`;

async function llm(user) {
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({ model: process.env.LLM_MODEL || 'claude-sonnet-5-5', max_tokens: 4000, system: SYS, messages: [{ role: 'user', content: user }] }),
    signal: AbortSignal.timeout(120000)
  });
  if (!r.ok) throw new Error(`llm_${r.status}`);
  const j = await r.json();
  return JSON.parse(j.content[0].text.replace(/^```json|```$/gm, '').trim());
}

const slugify = (s, n) => `${String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 60) || 'module'}-${n}`;
const clip = (s, n) => String(s || '').slice(0, n);
const KINDS = ['whois', 'domain', 'token', 'ipoffset'];

function pdf(m) {
  const file = `${m.slug}.pdf`;                       // slug is regex-validated: no path traversal
  const doc = new PDFDocument({ margin: 56, info: { Title: m.title.en } });
  doc.pipe(fs.createWriteStream(path.join(PDF_DIR, file)));
  doc.fontSize(20).text(`IHM-${m.order}: ${m.title.en}`).moveDown().fontSize(11).text(m.body.en);
  doc.addPage().fontSize(16).text('Roman Urdu').moveDown().fontSize(11).text(m.body.ur);
  doc.addPage().fontSize(16).text('Labs').moveDown().fontSize(11).list(m.labs.map(l => l.title));
  doc.end();
  return file;
}

exports.ingest = async (jobId, text, count) => {
  const job = { id: jobId, total: count, done: 0, failed: 0, state: 'running', iocs: extract(text) };
  jobs.set(jobId, job);
  const start = (await Module.countDocuments()) + 1, titles = [];
  const window = Math.max(2000, Math.floor(text.length / count));
  for (let i = 0; i < count; i++) {
    try {
      const order = start + i;
      const excerpt = text.slice((i * window) % Math.max(1, text.length - 6000), (i * window) % Math.max(1, text.length - 6000) + 6000);
      const d = await llm(`Module ${order}. IOC type counts in source: ${JSON.stringify(job.iocs)}.\nAlready covered titles (do not repeat): ${titles.slice(-40).join('; ')}\nSource excerpt:\n${excerpt}`);
      const mod = {
        order, slug: slugify(d.title.en, order),
        title: { en: clip(d.title.en, 120), ur: clip(d.title.ur, 120) }, summary: clip(d.summary, 300),
        body: { en: clip(d.body.en, 6000), ur: clip(d.body.ur, 6000) },
        labs: d.labs.slice(0, 5).map((l, k) => ({ id: `m${order}-l${k + 1}`, title: clip(l.title, 120), kind: KINDS.includes(l.kind) ? l.kind : KINDS[k % 4], prompt: clip(l.prompt, 500) }))
      };
      mod.pdf = pdf(mod);
      await Module.create(mod);
      titles.push(mod.title.en);
      job.done++;
    } catch (e) { job.failed++; job.lastError = e.message; }
  }
  job.state = 'finished';
};

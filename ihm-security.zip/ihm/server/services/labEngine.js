// Polymorphic lab instances: every (user, lab) pair gets its own deterministic synthetic target.
// All data is fictional (RFC 5737 / .test names). Answers are never stored; they are re-derived and hashed on verify.
const crypto = require('crypto');
const sha256 = s => crypto.createHash('sha256').update(s).digest('hex');

function prng(seed) {
  let s = crypto.createHmac('sha256', process.env.LAB_SECRET).update(seed).digest().readUInt32BE(0);
  return () => { s |= 0; s = (s + 0x6D2B79F5) | 0; let t = Math.imul(s ^ (s >>> 15), 1 | s); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

function make(userId, lab) {
  const r = prng(`${userId}:${lab.id}`);
  const hex = n => Array.from({ length: n }, () => Math.floor(r() * 16).toString(16)).join('');
  const base = 1 + Math.floor(r() * 40), offset = 10 + Math.floor(r() * 190);
  const v = {
    domain: `${hex(6)}.ihm-lab.test`, token: `tk_${hex(16)}`, handle: `ghost_${hex(5)}`,
    sub: `vpn-${hex(4)}`, base: `203.0.113.${base}`, offset, ip: `198.51.100.${1 + Math.floor(r() * 253)}`
  };
  const shuffle = a => a.map(x => [r(), x]).sort((p, q) => p[0] - q[0]).map(p => p[1]);
  let answer, lines;
  switch (lab.kind) {
    case 'whois':
      answer = v.handle;
      lines = shuffle([`Domain: ${v.domain}`, `Registrar: IHM Synthetic Registrar`, `Registrant-Handle: ${v.handle}`,
        `Tech-Contact: ghost_${hex(5)}`, `Billing-Contact: ghost_${hex(5)}`, `Abuse-Contact: abuse@ihm-lab.test`]);
      break;
    case 'domain':
      answer = v.sub;
      lines = shuffle([`${v.sub}.${v.domain} A ${v.ip}`, ...Array.from({ length: 7 }, () => `${['mail', 'dev', 'cdn', 'api', 'git'][Math.floor(r() * 5)]}-${hex(4)}.${v.domain} A 198.51.100.${1 + Math.floor(r() * 253)}`)]);
      break;
    case 'token':
      answer = v.token;
      lines = shuffle([`GET /health 200`, `GET /login 302`, `GET /api/export 200 X-Debug-Token: ${v.token}`, ...Array.from({ length: 6 }, () => `GET /static/${hex(6)}.js 200`)]);
      break;
    default:
      answer = `203.0.113.${base + offset}`;
      lines = [`Pivot base: ${v.base}`, `Observed offset between hosts: +${offset}`, 'Task: give the host at base + offset.'];
  }
  return { v, answer, lines };
}

exports.render = (userId, lab) => lab.prompt.replace(/\{(\w+)\}/g, (_, k) => make(userId, lab).v[k] ?? '');
exports.evidence = (userId, lab) => make(userId, lab).lines;
exports.check = (userId, lab, given) => {
  const want = Buffer.from(sha256(make(userId, lab).answer.toLowerCase()), 'hex');
  const got = Buffer.from(sha256(String(given).trim().toLowerCase()), 'hex');
  return crypto.timingSafeEqual(want, got);
};
exports.sha256 = sha256;

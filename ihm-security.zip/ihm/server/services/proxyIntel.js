// Server-side intel proxy: keys stay in .env, browser never sees them, CORS is moot.
// Only allowlisted targets (your own infra / public practice hosts) can be queried; private ranges are refused (SSRF).
const net = require('net');
const dns = require('dns').promises;
const bad = m => Object.assign(new Error(m), { status: 400, expose: true });
const allow = () => new Set((process.env.INTEL_ALLOWLIST || '').split(',').map(s => s.trim().toLowerCase()).filter(Boolean));
const priv = ip => /^(10\.|127\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|0\.|::1|f[cd]|fe80)/i.test(ip);

async function resolveTarget(target) {
  if (typeof target !== 'string' || !/^[a-z0-9.-]{1,253}$/i.test(target)) throw bad('invalid_target');
  if (!allow().has(target.toLowerCase())) throw bad('target_not_allowlisted');
  const ip = net.isIP(target) ? target : (await dns.lookup(target)).address;
  if (priv(ip)) throw bad('private_range');
  return ip;
}
const get = async (url, headers = {}) => {
  const r = await fetch(url, { headers, signal: AbortSignal.timeout(8000) });
  if (!r.ok) throw bad(`upstream_${r.status}`);
  return r.json();
};

exports.lookup = async (source, target) => {
  const ip = await resolveTarget(target);
  if (source === 'shodan') {
    if (!process.env.SHODAN_KEY) throw bad('shodan_not_configured');
    const d = await get(`https://api.shodan.io/shodan/host/${ip}?key=${encodeURIComponent(process.env.SHODAN_KEY)}`);
    return { ip, ports: d.ports, org: d.org, hostnames: d.hostnames, os: d.os };
  }
  if (source === 'censys') {
    if (!process.env.CENSYS_ID) throw bad('censys_not_configured');
    const auth = Buffer.from(`${process.env.CENSYS_ID}:${process.env.CENSYS_SECRET}`).toString('base64');
    const d = await get(`https://search.censys.io/api/v2/hosts/${ip}`, { Authorization: `Basic ${auth}` });
    return d.result;
  }
  if (source === 'whois') return get(`https://rdap.org/ip/${ip}`);
  throw bad('unknown_source');
};

import { useEffect, useRef, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { api } from '../lib/api.js';

const OPS = `/api/${import.meta.env.VITE_OPS_PREFIX}`;

export default function Secret() {
  const [state, setState] = useState('check'), [metrics, setMetrics] = useState(null), [job, setJob] = useState(null);
  const [text, setText] = useState(''), [count, setCount] = useState(100), [msg, setMsg] = useState('');
  const file = useRef();

  useEffect(() => {
    let live = true;
    const tick = () => api(`${OPS}/metrics`).then(m => { if (live) { setMetrics(m); setState('ok'); } }).catch(() => live && setState('deny'));
    tick(); const t = setInterval(tick, 5000);
    return () => { live = false; clearInterval(t); };
  }, []);

  useEffect(() => {
    if (!job || job.state === 'finished') return;
    const t = setInterval(() => api(`${OPS}/jobs/${job.id}`).then(setJob).catch(() => {}), 3000);
    return () => clearInterval(t);
  }, [job && job.id, job && job.state]);

  const start = async () => {
    const fd = new FormData();
    if (file.current?.files[0]) fd.append('seed', file.current.files[0]); else fd.append('text', text);
    fd.append('count', count);
    try { const { job: id } = await api(`${OPS}/ingest`, { method: 'POST', body: fd }); setJob({ id, state: 'running', done: 0, total: count, failed: 0 }); setMsg(''); }
    catch (e) { setMsg(e.message); }
  };

  if (state === 'deny') return <Navigate to="/" replace />;   // looks like any unknown URL
  if (state === 'check') return <main className="dim">…</main>;
  return (
    <main>
      <h1>Seed intake</h1>
      <p className="dim">Upload source material. The pipeline builds bilingual modules, PDFs, labs and flags.</p>
      <div className="row"><input ref={file} type="file" accept=".txt,.md,.csv,.json" aria-label="Seed file" />
        <input type="number" min="1" max="150" value={count} onChange={e => setCount(+e.target.value)} aria-label="Module count" style={{ maxWidth: 110 }} /></div>
      <textarea rows="6" style={{ width: '100%' }} value={text} onChange={e => setText(e.target.value)} placeholder="…or paste the seed text here" aria-label="Seed text" />
      <div className="row"><button onClick={start}>Generate modules</button></div>
      {msg && <p className="err">{msg}</p>}
      {job && <pre>{`job ${job.id}  ${job.state}\n${job.done}/${job.total} done, ${job.failed} failed${job.lastError ? '\nlast error: ' + job.lastError : ''}`}</pre>}
      <h2>System</h2>
      {metrics && <pre>{`db ${metrics.db} | uptime ${metrics.uptime}s | rss ${metrics.rssMB}MB | heap ${metrics.heapMB}MB\nmodules ${metrics.modules} | users ${metrics.users}\n\n` +
        metrics.recent.map(r => `${new Date(r.createdAt).toISOString()}  ${r.action}  ${r.actor}  ${r.ip}`).join('\n')}</pre>}
    </main>);
}

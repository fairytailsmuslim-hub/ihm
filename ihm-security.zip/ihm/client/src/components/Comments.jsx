import { useEffect, useState } from 'react';
import DOMPurify from 'dompurify';
import { api } from '../lib/api.js';

const safe = t => DOMPurify.sanitize(t, { ALLOWED_TAGS: [], ALLOWED_ATTR: [] });

export default function Comments({ target }) {
  const [list, setList] = useState([]), [text, setText] = useState(''), [parent, setParent] = useState(null), [err, setErr] = useState('');
  const load = () => api(`/api/comments/${target}`).then(setList).catch(() => {});
  useEffect(() => { load(); }, [target]);
  const send = async () => {
    try { await api(`/api/comments/${target}`, { method: 'POST', body: { text, parent } }); setText(''); setParent(null); setErr(''); load(); }
    catch (e) { setErr(e.message); }
  };
  const node = (c, depth = 0) => (
    <div key={c._id} className={depth ? 'reply' : ''}>
      <p><b>{safe(c.handle)}</b> <span className="dim">{new Date(c.createdAt).toLocaleString()}</span><br />{safe(c.text)}{' '}
        <button onClick={() => setParent(c._id)}>Reply</button></p>
      {list.filter(x => x.parent === c._id).map(x => node(x, depth + 1))}
    </div>);
  return (
    <section aria-label="Discussion">
      <h3>Discussion</h3>
      {list.filter(c => !c.parent).map(c => node(c))}
      <div className="row"><input value={text} maxLength={1000} onChange={e => setText(e.target.value)} placeholder={parent ? 'Write a reply' : 'Share feedback or a question'} aria-label="Comment" />
        <button disabled={!text.trim()} onClick={send}>Post comment</button>{parent && <button onClick={() => setParent(null)}>Cancel reply</button>}</div>
      {err && <p className="err">{err}</p>}
    </section>);
}

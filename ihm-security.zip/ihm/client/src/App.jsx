import { useEffect, useState } from 'react';
import { Routes, Route, Link, useParams } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { api } from './lib/api.js';
import { vaultSet, vaultGet } from './lib/vault.js';
import Comments from './components/Comments.jsx';
import Secret from './components/Secret.jsx';

function Auth({ onDone }) {
  const [f, setF] = useState({ handle: '', email: '', password: '' }), [mode, setMode] = useState('login'), [err, setErr] = useState('');
  const set = k => e => setF({ ...f, [k]: e.target.value });
  const go = async () => { try { await api(`/api/auth/${mode}`, { method: 'POST', body: f }); onDone(); } catch (e) { setErr(e.message); } };
  return (
    <main><h1>IHRTECH SECURITY</h1>
      <div className="row">{mode === 'register' && <input placeholder="handle" value={f.handle} onChange={set('handle')} aria-label="Handle" />}
        <input placeholder="email" value={f.email} onChange={set('email')} aria-label="Email" />
        <input placeholder="password (10+ chars)" type="password" value={f.password} onChange={set('password')} aria-label="Password" /></div>
      <div className="row"><button onClick={go}>{mode === 'login' ? 'Log in' : 'Create account'}</button>
        <button onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>{mode === 'login' ? 'Need an account?' : 'Have an account?'}</button></div>
      {err && <p className="err">{err}</p>}</main>);
}

function Home({ me }) {
  const [mods, setMods] = useState(null);
  useEffect(() => { api('/api/learn/modules').then(async m => { setMods(m); await vaultSet('rank', { unlocked: m.filter(x => !x.locked).length }); }); }, []);
  if (!mods) return <main className="dim">loading…</main>;
  if (!mods.length) return <main><h1>No modules yet</h1><p className="dim">Content appears here once the first seed is ingested.</p></main>;
  return (
    <main><h1>Learning matrix</h1>
      {mods.map(m => <div key={m.order} className={`mod ${m.locked ? 'locked' : ''}`}>
        {m.locked ? <span>{m.title.en}</span> : <Link to={`/learn/${m.order}`}>{m.title.en}</Link>}
        <span>{m.locked ? 'locked' : 'open'}</span></div>)}</main>);
}

function Lab({ lab, onSolved }) {
  const [ev, setEv] = useState(null), [ans, setAns] = useState(''), [res, setRes] = useState(null);
  const verify = async () => { const r = await api(`/api/learn/labs/${lab.id}/verify`, { method: 'POST', body: { answer: ans } }).catch(e => ({ correct: false, error: e.message })); setRes(r); if (r.correct) onSolved(); };
  return (
    <div className={`lab ${lab.solved ? 'solved' : ''}`}>
      <h3>{lab.title}</h3><p>{lab.prompt}</p>
      <button onClick={() => api(`/api/learn/labs/${lab.id}/evidence`).then(r => setEv(r.lines))}>Load evidence</button>
      {ev && <pre>{ev.join('\n')}</pre>}
      <div className="row"><input value={ans} onChange={e => setAns(e.target.value)} placeholder="answer" aria-label="Answer" />
        <button onClick={verify}>Verify</button></div>
      {res && (res.correct ? <p className="good">Verified.</p> : <p className="err">{res.error === 'too_many_attempts' ? 'Slow down and retry shortly.' : 'Incorrect.'}</p>)}
    </div>);
}

function Module() {
  const { order } = useParams(), [m, setM] = useState(null), [lang, setLang] = useState('en'), [err, setErr] = useState('');
  const load = () => api(`/api/learn/modules/${order}`).then(setM).catch(e => setErr(e.status === 403 ? 'Solve every lab in the previous module to unlock this one.' : e.message));
  useEffect(() => { setM(null); setErr(''); load(); }, [order]);
  if (err) return <main><p className="err">{err}</p><Link to="/">Back to matrix</Link></main>;
  if (!m) return <main className="dim">loading…</main>;
  return (
    <main>
      <Helmet><title>{m.title.en} | IHRTECH SECURITY</title><meta name="description" content={m.summary} /><link rel="canonical" href={`${location.origin}/learn/${m.slug}`} /></Helmet>
      <h1>{m.title[lang]}</h1>
      <div className="row"><button onClick={() => setLang(lang === 'en' ? 'ur' : 'en')}>{lang === 'en' ? 'Roman Urdu' : 'English'}</button>
        <a href={`/api/learn/modules/${m.order}/pdf`}>Download PDF</a></div>
      <article style={{ whiteSpace: 'pre-wrap' }}>{m.body[lang]}</article>
      {m.labs.map(l => <Lab key={l.id} lab={l} onSolved={load} />)}
      <Comments target={`module:${m.slug}`} />
    </main>);
}

export default function App() {
  const [me, setMe] = useState(undefined);
  const refresh = () => api('/api/auth/me').then(setMe).catch(() => setMe(null));
  useEffect(() => { refresh(); }, []);
  if (me === undefined) return null;
  return (
    <>
      <header><Link to="/">IHRTECH SECURITY</Link>
        {me && <span className="dim">{me.handle} · {me.score} pts <button onClick={() => api('/api/auth/logout', { method: 'POST' }).then(() => setMe(null))}>Log out</button></span>}</header>
      <Routes>
        <Route path={import.meta.env.VITE_SECRET_ROUTE || '/secret'} element={me ? <Secret /> : <Auth onDone={refresh} />} />
        <Route path="*" element={!me ? <Auth onDone={refresh} /> : <Routes><Route path="/" element={<Home me={me} />} /><Route path="/learn/:order" element={<Module />} /></Routes>} />
      </Routes>
    </>);
}

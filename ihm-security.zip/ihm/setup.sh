#!/usr/bin/env bash
set -e
npm install express mongoose dotenv cors helmet express-rate-limit cookie-parser express-mongo-sanitize hpp geoip-lite isomorphic-dompurify jsonwebtoken bcryptjs multer pdfkit
(cd client && npm install react react-dom react-router-dom react-helmet-async dompurify xterm && npm install -D vite @vitejs/plugin-react)
[ -f .env ] || cp .env.example .env
echo "Edit .env (secrets!) then: npm start  |  cd client && npx vite"
